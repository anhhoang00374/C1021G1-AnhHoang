use case_study_furama;
update v_nhan_vien
set dia_chi = "Liên Chiểu";

