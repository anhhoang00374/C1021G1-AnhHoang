package com.codegym.cms;

public class DuplicateEmailException extends Exception{
}
