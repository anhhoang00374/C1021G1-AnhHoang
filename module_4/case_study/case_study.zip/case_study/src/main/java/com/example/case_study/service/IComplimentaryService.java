package com.example.case_study.service;

import com.example.case_study.model.Complimentary;

import java.util.List;

public interface IComplimentaryService {
    List<Complimentary> findAll();
}
