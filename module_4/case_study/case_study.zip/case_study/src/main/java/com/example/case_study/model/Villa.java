package com.example.case_study.model;


public class Villa  extends FuramaService {
//    private String standardRoom;
//    private String descriptionOtherConvenience;
//    private float poolArea;
//    private  int numberOfFloors;

    public Villa() {
    }




}
