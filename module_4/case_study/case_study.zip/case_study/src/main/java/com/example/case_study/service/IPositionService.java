package com.example.case_study.service;

import com.example.case_study.model.Position;

import java.util.List;

public interface IPositionService {
    List<Position> findAll();
}
