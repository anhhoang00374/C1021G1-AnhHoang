package com.example.case_study.model;

public class ContractDetail {
    private int contractDetailId;
    private int contractId;
    private int attachService;
    private int quantity;
}
