package com.example.case_study.service;

import com.example.case_study.model.RentType;

import java.util.List;

public interface IRentypeService {
    List<RentType> findAll();
}
