package com.example.case_study.service;

import com.example.case_study.model.ServiceType;

import java.util.List;

public interface IServiceTypeService {
    List<ServiceType> findAll();
}
