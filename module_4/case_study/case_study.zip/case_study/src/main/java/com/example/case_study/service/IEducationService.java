package com.example.case_study.service;

import com.example.case_study.model.Education;

import java.util.List;

public interface IEducationService {
    List<Education> findAll();
}
