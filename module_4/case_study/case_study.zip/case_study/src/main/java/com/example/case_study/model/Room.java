package com.example.case_study.model;

public class Room extends FuramaService {

}
