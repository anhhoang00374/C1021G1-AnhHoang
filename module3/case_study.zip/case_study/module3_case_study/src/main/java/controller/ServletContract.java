package controller;

import model.abstract_class.Contract;
import service.IContractService;
import service.impl.ContractServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ServletContract", value = "/ServletContract")
public class ServletContract extends HttpServlet {
    IContractService iContractService = new ContractServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if(action==null){
            action = "";
        }
        switch (action){
            case "create":
                break;
            default:
                displayContract(request,response);
        }
    }

    private void displayContract(HttpServletRequest request, HttpServletResponse response) {
        List<Contract> contractList = iContractService.selectAll();
        try {
            request.getRequestDispatcher("contract.jsp").forward(request,response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
